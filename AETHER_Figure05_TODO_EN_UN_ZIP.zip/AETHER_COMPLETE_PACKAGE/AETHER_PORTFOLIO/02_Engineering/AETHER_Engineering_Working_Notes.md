# AETHER hand/forearm — engineering working notes (Rev 0.2)

## Design question
Can a hand/forearm module be designed so that fingertip wear or tactile-sensor replacement is quicker and calibration repeatability is measurable, without unacceptable losses in dexterity, mass, backlash, or reliability?

## Hypothesis (not validated)
A removable fingertip cartridge plus a serviceable actuation/transmission subassembly and a documented calibration routine may improve maintainability and fault isolation. The extra interfaces may also create failure modes. This must be compared to a baseline design using controlled tests.

## Scope of the first demonstrator
- One hand and forearm; no full biped robot.
- Guarded bench fixture; no human-facing collaborative operation before hazard analysis.
- Initial objective: measure repeatability and maintainability, not claim best-in-class grip performance.
- Avoid final actuator selection until kinematics, force envelope, speed, duty cycle and thermal limits are specified.

## Initial envelope targets (not manufacturing dimensions)
- Wrist-reference to fingertip envelope: approximately 190 mm.
- Palm width envelope: approximately 86 mm.
- Five-digit layout in the visual concept.
- Joint count, active DoF, underactuation map, actuator count, motor torque and sensor specifications: OPEN.

These values are visual/ergonomic starting points only. They must be confirmed through anthropometric references, grasp tasks, collision analysis and CAD.

## First requirements to close
1. Use cases: choose three objects/tasks with size, mass, material and required manipulation.
2. Grasp envelope: define desired pinch and power grasps, approach directions, orientation limits and allowed contact force.
3. Kinematics: joint axes, ranges, hard stops, coupling and desired tendon/gear ratios.
4. Actuation: speed, peak/continuous torque, thermal duty, transmission loss, backdrivability and noise.
5. Sensing: tactile array range, spatial resolution, sample rate, calibration, drift and fault detection.
6. Service design: fasteners, tool list, connector keying, module identity, replacement sequence and post-service checks.
7. Safety: pinch-point review, maximum force/torque, guarded test rig, e-stop and safe restart procedure.
8. Data: test IDs, versioned files, raw samples, calibration records and error definitions.

## First analysis tasks
- Kinematic chain and range-of-motion envelope.
- Interference and self-collision check.
- Static finger torque estimate: derive from object mass, contact geometry, leverage and selected grasp type; do not use a guessed motor rating.
- Transmission efficiency / tendon tension estimate, including bend friction and preload.
- Motor continuous/peak selection using real supplier curves and duty cycle.
- Thermal balance using losses and realistic ambient/heat paths.
- Mass budget for palm, fingers, actuators, sensors, cables and housing.
- Tolerance stack-up and connector alignment.

## Test matrix (draft)
- Sensor calibration / linearity / hysteresis / repeatability.
- Module replacement time and post-service calibration shift.
- Repeated grasp cycles across agreed object classes.
- Slip detection and grip adjustment under controlled slip events.
- Actuator current and temperature over the duty profile.
- Wear at joints, routing paths, and connector interface.
- Fault injection: disconnected sensor, stale data, communication loss, actuator limit event.

## Evidence standard
Every reported value should include unit, method, instrument, sample count, environment, firmware/hardware revision and uncertainty or limitations. Clearly distinguish: PUBLIC FACT, DESIGN TARGET, ASSUMPTION, CALCULATED ESTIMATE, SIMULATION RESULT, MEASURED RESULT.
