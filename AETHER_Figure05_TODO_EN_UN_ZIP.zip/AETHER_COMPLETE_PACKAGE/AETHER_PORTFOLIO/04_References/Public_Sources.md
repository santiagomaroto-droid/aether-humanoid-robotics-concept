# Public references checked 29 October 2026

1. Figure AI, “Introducing Figure 03,” 9 October 2025. https://www.figure.ai/news/introducing-figure-03
   Relevant published details: sensory suite; embedded palm camera; tactile fingertip sensor; home-oriented design; design for high-volume manufacturing.

2. Figure AI, “Introducing Helix 02: Full-Body Autonomy,” 27 January 2026. https://www.figure.ai/news/helix-02
   Relevant published details: whole-body control; vision, touch and proprioception; palm cameras and tactile fingertip use cases.

3. Figure AI, “Ramping Figure 03 Production,” 29 April 2026. https://www.figure.ai/news/ramping-figure-03-production
   Relevant published details: production scale-up, manufacturing quality checks, actuators, service loops and diagnostics.

4. Figure AI, “F.02 Decommission,” 30 September 2026. https://www.figure.ai/news/f-02-decommission
   Relevant only to public mention of a planned F.04 launch; does not provide a complete F.04 technical specification.

5. Figure AI, Careers. https://www.figure.ai/careers
   Use for live role availability and application instructions. Check again at submission time.

6. Figure AI, Company. https://www.figure.ai/company
   Company-level product evolution context.

## Source discipline
This study only uses public sources. It does not claim access to internal specifications. The reference comparison is informational and should be checked again before sending.
