# Checklist de candidatura — personalizar antes de enviar

Este documento evita que el portfolio dé a entender experiencia que aún no se ha demostrado. Rellena solo información verdadera y verificable.

## Datos de contacto
- Nombre y apellidos: [COMPLETAR]
- Email profesional: [COMPLETAR]
- LinkedIn: [URL, si existe]
- Portfolio / repositorio: [URL, si existe]
- Ubicación y disponibilidad para reubicación: [COMPLETAR]

## Perfil y objetivo
- Puesto concreto al que se presenta candidatura: [ENLACE A VACANTE]
- Área principal: [diseño industrial / CAD mecánico / mecatrónica / robótica / software / otra]
- Formación real relevante: [TÍTULO, CENTRO, FECHAS]
- Herramientas dominadas y nivel real: [Fusion 360 / SolidWorks / Onshape / ROS 2 / Python / MATLAB / otras; solo si es cierto]
- Proyectos previos demostrables: [ENLACE, rol y contribución personal]

## Evidencia que conviene añadir cuando exista
- [ ] Archivo CAD paramétrico editable y export STEP.
- [ ] Despiece y planos con tolerancias / materiales definidos.
- [ ] Cálculos reproducibles y fuentes de componentes.
- [ ] Simulación con método, condiciones de contorno y limitaciones.
- [ ] Vídeo de prototipo real, si existe.
- [ ] Datos de pruebas, incluyendo fallos, tamaño de muestra y condiciones.
- [ ] README con instrucciones para reproducir el trabajo.

## Regla de honestidad
No convertir una imagen generada en un render CAD. No describir cálculos propuestos como resultados. No afirmar que se construyó o probó un módulo si no sucedió. Explica claramente cuál fue tu contribución personal.
