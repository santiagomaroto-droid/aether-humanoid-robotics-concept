# AETHER — FIGURE 05 / Independent Concept Study

**Paquete de candidatura y portfolio conceptual — revisión 0.2 — 29 de octubre de 2026**

## Qué es
AETHER es un estudio independiente y especulativo sobre una posible futura plataforma humanoide. No es un producto oficial de Figure AI, no está respaldado por Figure y no utiliza información confidencial. “Figure 05” se usa como marco hipotético, no como afirmación sobre un producto anunciado.

## Cómo usar este paquete
1. Lee `02_Engineering/AETHER_Engineering_Concept_Brief.pdf`.
2. Revisa la presentación `01_Concept_Design/AETHER_Concept_Presentation.pdf` y conserva el PPTX editable para adaptar el discurso.
3. Consulta `02_Engineering/AETHER_Hand_Forearm_Concept_Sheet.pdf`. Es un plano conceptual de envolvente; **no sirve para fabricar**.
4. Personaliza `03_Application/Email_Draft_EN.txt`, `Candidate_Profile_Checklist_ES.md` y el CV.
5. No envíes hasta sustituir los campos pendientes, revisar que las competencias descritas son reales y elegir una vacante o canal adecuado.

## Qué incluye
- Presentación visual editable y PDF.
- Informe técnico-conceptual con estado de evidencia, requisitos propuestos, riesgos, plan de validación y fuentes.
- Plano conceptual de mano/antebrazo y activos visuales.
- Borrador de email en inglés con asunto.
- Checklist para adaptar el portfolio a una candidatura real.
- Fuentes oficiales consultadas.

## Estado real del trabajo
- **Completado:** concepto visual, arquitectura narrativa, propuesta preliminar de subsistema, matriz inicial de requisitos y plan de verificación.
- **Pendiente:** CAD paramétrico, selección dimensionada de componentes, cálculos de fuerza/par/potencia/temperatura, simulación, prototipo, pruebas, resultados medidos y revisión de seguridad.
- **No afirmar:** que exista un prototipo funcional, que haya simulaciones superadas, que se hayan validado prestaciones o que las imágenes sean CAD real.

## Siguiente hito recomendado
Desarrollar un modelo CAD paramétrico de mano y antebrazo, decidir un caso de uso concreto, documentar supuestos y realizar cálculos preliminares antes de seleccionar actuadores o fabricar componentes.

## Contexto público de Figure
Figure 03 ya incorpora visión en la palma y sensores táctiles de dedos. Helix 02 integra visión, tacto y propiocepción en el control del cuerpo completo. Por tanto, la hipótesis de diferenciación propuesta es servicio, modularidad, calibración y verificabilidad — no inventar esas funciones de nuevo.

## Revisión de fuentes
Las referencias incluidas se consultaron el 29 de octubre de 2026. Comprueba de nuevo las noticias y vacantes oficiales antes de enviar, ya que las hojas de ruta y los puestos cambian.
